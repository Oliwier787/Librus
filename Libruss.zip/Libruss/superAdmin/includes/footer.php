  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                    &copy; <?php echo date('Y')?> Student Grading System - Developed By Sodiq Ahmed
                    </div>
                    <div class="col-sm-6 text-right">
                        <!-- Designed by <a href="https://colorlib.com">Colorlib</a> -->
                    </div>
                </div>
            </div>
        </footer>